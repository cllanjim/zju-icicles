#include<stdio.h>
#include<malloc.h>
#include<stdlib.h>
#fileheader
typedef struct tagBITMAPFILEHEADER
{
    unsigned char bfType[2];
    unsigned long bfSize;
    unsigned short bfReserved1;
    unsigned short bfReserved2;
    unsigned long bfOffBits;
}fileHeader;

#fileinfo
typedef struct tagBITMAPINFOHEADER
{
    unsigned long biSize;
    long biWidth;
    long biHeight;
    unsigned short biPlanes;
    unsigned short biBitCount;
    unsigned long biCompression;
    unsigned long biSizeImage;
    long biXPixPerMeter;
    long biYPixPerMeter;
    unsigned long biClrUsed;
    unsigned long biClrImporant;
}fileInfo;


#color
typedef struct tagRGBQUAD
{
    unsigned char rgbBlue; //blue header
    unsigned char rgbGreen;//green header
    unsigned char rgbRed;//red header
    unsigned char rgbReserved;
}rgbq;

int main()
{
    unsigned char ImgData[3000][3];
    unsigned char ImgData2[3000];
    int i,j,k;
    FILE * fpBMP,* fpGray;
    fileHeader * fh;
    fileInfo * fi;
    rgbq * fq;
    
    if((fpBMP=fopen("c:\\TURBOC3\\zzy1.bmp","rb"))==NULL)
    {
        printf("File Open Error\n");
        exit(0);
    }
    
	if((fpGray=fopen("c:\\TURBOC3\\happy.bmp","wb"))==NULL)
    {
        printf("File Open Error");
        exit(0);
    }
    
    fh=(fileHeader *)malloc(sizeof(fileHeader));
    fi=(fileInfo *)malloc(sizeof(fileInfo));
    fread(fh,sizeof(fileHeader),1,fpBMP);
    fread(fi,sizeof(fileInfo),1,fpBMP);
    fi->biBitCount=8;
    fi->biSizeImage=( (fi->biWidth*3+3)/4 ) * 4*fi->biHeight;
    //fi->biClrUsed=256;
    
    fh->bfOffBits = sizeof(fileHeader)+sizeof(fileInfo)+256*sizeof(rgbq);
    fh->bfSize = fh->bfOffBits + fi->biSizeImage;
    
    fq=(rgbq *)malloc(256*sizeof(rgbq));
    for(i=0;i<256;i++)
    {
        fq[i].rgbBlue=fq[i].rgbGreen=fq[i].rgbRed=i;
    }
   
    fwrite(fh,sizeof(fileHeader),1,fpGray);  
    fwrite(fi,sizeof(fileInfo),1,fpGray); 
    fwrite(fq,sizeof(rgbq),256,fpGray);
    
    for ( i=0;i<fi->biHeight;i++ )
    {
        for(j=0;j<(fi->biWidth+3)/4*4;j++)
        {
            for(k=0;k<3;k++)
                fread(&ImgData[j][k],1,1,fpBMP);
        }
        for(j=0;j<(fi->biWidth+3)/4*4;j++)
        {
            ImgData2[j]=(int)((float)ImgData[j][0] * 0.114 +
                        (float)ImgData[j][1] * 0.587 +
                        (float)ImgData[j][2] * 0.299 );
        }
        
        fwrite(ImgData2,j,1,fpGray);
    }   
        
        free(fh);
        free(fi);
        free(fq);
        fclose(fpBMP);
        fclose(fpGray);
        printf("success\n");
        return 0;
}
