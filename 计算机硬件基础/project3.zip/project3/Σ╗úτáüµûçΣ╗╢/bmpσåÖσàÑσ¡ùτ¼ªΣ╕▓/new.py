import PIL from Image, ImageDraw, ImageFont

if __name__ == "__main__":
    font = ImageFont.truetype("consola.ttf", 40, encoding="unic")
    draw.text((100, 50), u'Hello World', 'fuchsia', font)
