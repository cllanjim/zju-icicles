#include <stdio.h>
#include <dos.h>
#include <graphics.h>

#define VIDEO	0x10
#define WIDTH	800

typedef unsigned char	byte;

/*文件头结构*/
typedef struct tagBITMAPFILEHEADER
{
 int bfType; /* 通常是 'BM' 。现在来看似乎判断OS/2的标识已无什么意义*/
 long   bfSize; /* 文件大小，以字节为单位*/
 int bfReserved1; /*保留，必须设置为0*/
 int bfReserved2; /*保留，必须设置为0*/
 long bfOffBits; /*从文件头开始到实际的图象数据之间的字节的偏移量。这个参数是非常有用的，因为位图信息头和调色板的长度会根据不同情况而变化，可以用这个偏移值迅速的从文件中读取到位数据。 */
} BITMAPFILEHEADER;

/*信息头结构*/
typedef struct tagBITMAPINFOHEADER
{
 long biSize; /* 信息头大小 */
 long biWidth; /* 图像宽度 */
 long biHeight; /* 图像高度 */
 int biPlanes; /* 必须为1 */
 int biBitCount; /* 每像素位数，必须是1, 4, 8或24 */
 long biCompression; /* 压缩方法 */
 long biSizeImage; /* 实际图像大小，必须是4的倍数 */
 long biXPelsPerMeter; /* 水平方向每米像素数 */
 long biYPelsPerMeter; /* 垂直方向每米像素数*/
 long biClrUsed; /* 所用颜色数*/
 long biClrImportant; /* 重要的颜色数 */
} BITMAPINFOHEADER;

/*调色板*/
typedef struct tagRGBQUAD
{
 char rgbBlue; /*蓝色分量*/
 char rgbGreen; /*绿色分量*/
 char rgbRed; /*红色分量*/
 char rgbReserved; /*保留*/
} RGBQUAD;

BITMAPFILEHEADER	fh;
BITMAPINFOHEADER	bi;
RGBQUAD				rgb[256];

void videoInt(int ax, int bx, int cx, int dx)
{
   union REGS regs;

   regs.x.ax = ax;  /* set cursor position */
   regs.x.bx = bx;
   regs.x.cx = cx;
   regs.x.dx = dx;  /* video page 0 */
   int86(VIDEO, &regs, &regs);
}

byte far *p;
int	 curblock=0;
void setpixel(x, y, color){
	long	mk;
	mk = y*800L+x;
	if(curblock!=(mk>>16))videoInt(0x4F05, 0, 0, curblock=(mk>>16));
	p[mk&0xFFFF]=color;
}
void setrgb(byte *u, int start, int num)
{
	asm{
		mov		ax,1012h
		mov		bx,start
		mov		cx,num
		mov		dx,[bp+6]
		push	ss
		pop		es
		int		10h
	}
}

int main(int argc, char *argv[])
{
	int		i, j, k;
	int		temp;
	byte	u[400], colr[256*3];
	long	mk;
	FILE	*fp;

	if((fp=fopen("c:\\TURBOC3\\k398a.bmp", "rb"))==NULL){
		printf("file error!\n");	exit(0);
	}
	//clrscr();
	printf("%d, %d\n", sizeof(fh), sizeof(bi));
	fread(&fh, 1, sizeof(fh), fp);
	fread(&bi, 1, sizeof(bi), fp);
	fread(rgb, sizeof(RGBQUAD), 256, fp);
	for(j=0; j<256; j++){
		//colr[j*3+0] = rgb[j].rgbRed>>2;
		//colr[j*3+1] = rgb[j].rgbGreen>>2;
		//colr[j*3+2] = rgb[j].rgbBlue>>2;
		/*图像去色，变成灰度图像*/
          colr[3*j]=colr[3*j+1]=colr[3*j+2]=temp;
		//变成黑白图像 
        if(temp>128)
            colr[3*j]=colr[3*j+1]=colr[3*j+2]=255;
        else
            colr[3*j]=colr[3*j+1]=colr[3*j+2]=0;
	}

	//i=DETECT;	initgraph(&i, &j, "c:\\TURBOC3\\BGI");
	videoInt(0x4F02, 0x103, 0, 0);	//800x600 VESA
	setrgb(colr, 0, 256);
	p=MK_FP(0xA000,0);

	k=0;
	for(j=0; j<bi.biHeight; j++){
		fread(u, 1, bi.biWidth, fp);
		for(i=0; i<bi.biWidth; i++)setpixel(i+200, 400-j, u[i]);
	}

	printf("zouziyu_3170103064\n");
	getch();

	return 0;
}