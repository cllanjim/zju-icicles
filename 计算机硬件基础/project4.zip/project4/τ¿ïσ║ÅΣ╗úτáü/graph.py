# -*- coding: utf-8 -*-
# Created on 2018/7/18
import base64
import random
import os
import sys
import time

from PIL import Image, ImageFont, ImageDraw

reload(sys)
sys.setdefaultencoding('utf8')

BASE_PATH = "nanshen.bmp"  # original bmp location
TMP_PATH = "2.bmp"  # generating the new bmp
font_size = 35


# 216 194 119

class Addtxt:

    def __init__(self):
    	name = raw_input("input the string")
        self.name_append = name
        if not os.path.exists(TMP_PATH):
            os.mkdir(TMP_PATH)
        self.end_path = TMP_PATH + "new.bmp"  
        self.data = ""  # base64数据初始化
        self.pic_handle()
        self.base_64()

    def base_64(self):
        """
        将图片读成base64的格式，返回给移动端渲染
        :return:
        """
        res = open(self.end_path, 'rb')
        base64_data = base64.b64encode(res.read())
        res.close()
        d = {
            'image': 'data:image/bmp;base64,' + base64_data
        }
        self.data = d

    def pic_handle(self):
        # 底图路径
        img_path = BASE_PATH
        # 底图的操作对象
        font_img = Image.open(img_path).convert("RGB")
        # 即将在该底图上写字
        draw = ImageDraw.Draw(font_img)
        name_font = ImageFont.truetype("simkai.ttf", size=35)
        # 即将写的字
        name = self.name_append
        # 底图的宽高
        width = input('input the width (interger)')
        height = input('input the height(interger)')

        w = int(width)
        h = int(height)

        try:
            name_location = (((w - len(unicode(name, "UTF-8")) * font_size) / 2), h)
            draw.text(name_location, unicode(name, "UTF-8"), fill=(255,255,255), font=name_font)
        except BaseException as e:
            print e.message
            name_location = (((w - len(name) * font_size) / 2), h)
            draw.text(name_location, name, fill=(255,255,255), font=name_font)
        print self.end_path
        # 保存处理好的图片
        font_img.save(self.end_path)
        # 显示图片
        font_img.show()

    def end_data(self):
        return self.data


if __name__ == '__main__':
    Add_txt = Addtxt()
    return_data = Add_txt.end_data()
    print type(return_data)
